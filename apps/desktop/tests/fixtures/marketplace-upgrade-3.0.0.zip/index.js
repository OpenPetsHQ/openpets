OpenPetsPlugin.register({ start() { /* 3.0.0 */ } });
