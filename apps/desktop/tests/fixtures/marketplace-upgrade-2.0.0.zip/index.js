OpenPetsPlugin.register({ start() { /* 2.0.0 */ } });
